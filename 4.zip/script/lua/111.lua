nextbet = 0.00000001 --sets your first bet.
chance = 98
function dobet()
end