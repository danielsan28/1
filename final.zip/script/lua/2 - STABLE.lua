alvo = 99999999
apostaBase = 2500/10000000
bethigh = true
chance = 93
nextbet = apostaBase
numeroAbaixo = false
numeroAcima = true
sequenciaPerda = 0
sequenciaVirotia = 0

function atualizarNumeros()
	chanceAlta = math.random(9300,9310)/100
	chanceBaixa = math.random(5730,5920)/100
end

function zigue_zague()
	if numeroAcima == true then
		bethigh = false
		numeroAcima = false
		numeroAbaixo = true

		else
		bethigh = true
		numeroAcima = true
		numeroAbaixo = false
	end
end

function onWin()
    atualizarNumeros()
	if (win) then
		zigue_zague()
		chance = chanceBaixa
		nextbet = math.random(25,37)/10000000 --ESSE EH DIFERENTE
		sequenciaPerda = 0
		sequenciaVirotia += 1

		else
		chance = chanceAlta
		sequenciaPerda += 1
		sequenciaVirotia = 0

		if sequenciaPerda >= 1 then
			nextbet = 0.00020000
		end

		if sequenciaPerda >= 2 then
			nextbet = 0.00600000
		end

		if sequenciaPerda >= 3 then
			nextbet = 0.15930000
		end

		if sequenciaPerda >= 4 then
			nextbet = 4.78000000
		end

		if sequenciaPerda >= 5 then
			nextbet = 143.40000000
		end
	end
end

function dobet()
	onWin()
	atualizarNumeros()

	if balance >= alvo then
		stop()
	end

end